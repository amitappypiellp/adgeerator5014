from flask import Flask, render_template, request, jsonify
import os
from dotenv import load_dotenv
import openai
import base64
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

app = Flask(__name__)

# Configure OpenAI with API key directly
api_key = <OPENAPIKEY>

openai.api_key = api_key

@app.route('/')
def index():
    return render_template('index.html')

def get_dalle_size(width, height):
    # DALL-E supported sizes: 1024x1024, 1024x1792, 1792x1024
    aspect_ratio = width / height
    
    if 0.9 <= aspect_ratio <= 1.1:  # Square-ish
        return "1024x1024"
    elif aspect_ratio > 1.1:  # Wide
        return "1792x1024"
    else:  # Tall
        return "1024x1792"

def get_image_dimensions(ad_type, custom_dimensions=None):
    # Standard dimensions for different ad types
    dimensions = {
        'facebook-post': (1200, 1200),
        'facebook-story': (1080, 1920),
        'instagram-post': (1080, 1080),
        'instagram-story': (1080, 1920),
        'linkedin-post': (1200, 627),
        'twitter-post': (1200, 675),
        'banner-300x250': (300, 250),
        'banner-728x90': (728, 90),
        'banner-160x600': (160, 600),
        'email': (600, 600),
        'landing-page': (1200, 800),
        'print-ad': (2480, 3508)  # A4 size at 300 DPI
    }
    
    if custom_dimensions and all(custom_dimensions.values()):
        width = int(custom_dimensions['width'])
        height = int(custom_dimensions['height'])
    else:
        width, height = dimensions.get(ad_type, (1024, 1024))
    
    return get_dalle_size(width, height)

@app.route('/generate', methods=['POST'])
def generate_ad():
    try:
        data = request.json
        reference = data.get('reference', '')
        reference_image = data.get('reference_image')
        brand_voice = data.get('brand_voice', '')
        target_audience = data.get('target_audience', '')
        brand_colors = data.get('brand_colors', {})
        ad_type = data.get('ad_type', '')
        dimensions = data.get('dimensions')

        # Construct the prompt for the AI
        prompt = f"""Create an advertisement based on the following:

Reference content: {reference}

Brand Voice & Tone: {brand_voice}

Target Audience: {target_audience}

Brand Colors:
- Primary: {brand_colors.get('primary', 'Not specified')}
- Secondary: {brand_colors.get('secondary', 'Not specified')}
- Accent: {brand_colors.get('accent', 'Not specified')}

Ad Type: {ad_type}

Generate creative content that maintains brand voice and style while being engaging and effective for the specified target audience."""

        # If reference image is provided, note it in the prompt
        if reference_image:
            prompt += """

A reference image has been provided. When generating the ad content and image, maintain visual consistency with the brand's existing style."""


        # Generate content using OpenAI
        
        # Generate text content
        system_prompt = f"""You are a professional advertising copywriter. Create compelling ad copy that:
1. Is appropriate for the {ad_type} format
2. Uses a {brand_voice} tone of voice
3. Speaks directly to {target_audience}
4. Is concise and impactful
5. Includes a clear call-to-action
6. Does NOT include emojis or hashtags unless specifically requested
7. Does NOT include meta-commentary about colors or design
8. Focuses on benefits and value proposition"""

        messages = [
            {"role": "system", "content": system_prompt}
        ]

        # Enhance prompt with visual consistency guidance
        if reference_image:
            visual_prompt = """Note: A reference image has been provided. The generated content should:
1. Match the visual style and tone of the reference image
2. Use language that complements the image's aesthetic
3. Create a cohesive visual-verbal connection
4. Maintain brand consistency across both text and visuals"""
            
            messages.append({"role": "user", "content": f"{visual_prompt}\n\nReference content: {reference}\n\nCreate ad copy that aligns with both the visual reference and the content."})
        else:
            messages.append({"role": "user", "content": f"Create ad copy based on this content: {reference}"})

        response = openai.chat.completions.create(
            model="gpt-4",
            messages=messages
        )
        generated_content = response.choices[0].message.content

        # Process the reference image
        if reference_image:
            # Clean up and decode base64 image data
            image_data = reference_image
            if ';base64,' in image_data:
                image_data = image_data.split(';base64,')[1]
            
            # Convert to image
            img_bytes = base64.b64decode(image_data)
            img = Image.open(BytesIO(img_bytes))
            
            # Convert to RGB mode to avoid RGBA issues
            img = img.convert('RGB')
            
            # Create a drawing layer
            draw = ImageDraw.Draw(img)
            
            # Set text properties
            font_size = 40
            try:
                font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", font_size)
            except:
                font = ImageFont.load_default()
            
            # Get text color from brand colors
            text_color = tuple(int(brand_colors.get('primary', '#000000').lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
            
            # Define the bounding box for the text area
            bbox = (100, 100, 500, 200)  # Adjust these coordinates as needed
            draw.rectangle(bbox, fill='white')  # Clear the area where the old text was
            
            # Add new text using only the reference content
            text = reference  # Use the reference content directly
            draw.text((100, 100), text, fill=text_color, font=font)
            
            # Save as JPEG
            output = BytesIO()
            img.save(output, format='JPEG', quality=95)
            output.seek(0)
            
            # Create data URL
            image_data = base64.b64encode(output.getvalue()).decode()
            image_url = f"data:image/jpeg;base64,{image_data}"
        else:
            # If no reference image, generate a new one with DALL-E
            image_size = get_image_dimensions(ad_type, dimensions)
            image_prompt = f"Create a professional {ad_type} advertisement with the following content: {generated_content[:200]}"
            
            image_response = openai.images.generate(
                prompt=image_prompt,
                model="dall-e-3",
                size=image_size,
                quality="standard",
                n=1
            )
            
            image_url = image_response.data[0].url

        return jsonify({
            'success': True,
            'content': generated_content,
            'image_url': image_url
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, port=5014)
