# AI Ad Generator

An intelligent web application that generates brand-aligned creative content based on reference materials using AI.

## Features

- Generate ad content based on reference materials
- Maintain brand voice and style guidelines
- Support for multiple ad types (social media, email, display ads, landing pages)
- Modern, responsive UI
- Copy-to-clipboard functionality

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure OpenAI API key:
- Rename `.env.example` to `.env`
- Add your OpenAI API key to the `.env` file:
```
OPENAI_API_KEY=your_api_key_here
```

3. Run the application:
```bash
python app.py
```

4. Open your browser and navigate to `http://localhost:5000`

## Usage

1. Enter your reference content in the first text area
2. Provide brand guidelines including voice, tone, and style
3. Select the type of ad you want to generate
4. Click "Generate Ad" to create your content
5. Use the "Copy to Clipboard" button to easily copy the generated content

## Technologies Used

- Backend: Python Flask
- Frontend: HTML5, CSS3, JavaScript
- AI: OpenAI GPT-4
- Styling: Custom CSS with modern design principles
