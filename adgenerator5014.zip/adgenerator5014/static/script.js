// Convert file to base64 string
async function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const generateBtn = document.getElementById('generate-btn');
    const copyBtn = document.getElementById('copy-btn');
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const referenceImageInput = document.getElementById('reference-image');
    const referenceImagePreview = document.getElementById('reference-image-preview');
    const adTypeSelect = document.getElementById('ad-type');
    const dimensionsGroup = document.querySelector('.dimensions-group');

    // Handle reference image upload and preview
    referenceImageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                referenceImagePreview.innerHTML = `<img src="${e.target.result}" alt="Reference image preview">`;
                referenceImagePreview.classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        } else {
            referenceImagePreview.innerHTML = '';
            referenceImagePreview.classList.add('hidden');
        }
    });

    // Show/hide custom dimensions based on ad type
    adTypeSelect.addEventListener('change', () => {
        const selectedValue = adTypeSelect.value;
        if (selectedValue === 'custom') {
            dimensionsGroup.classList.remove('hidden');
        } else {
            dimensionsGroup.classList.add('hidden');
        }
    });

    generateBtn.addEventListener('click', async () => {
        const reference = document.getElementById('reference').value;
        const referenceImage = referenceImageInput.files[0];
        const brandVoice = document.getElementById('brand-voice').value;
        const targetAudience = document.getElementById('target-audience').value;
        const primaryColor = document.getElementById('primary-color').value;
        const secondaryColor = document.getElementById('secondary-color').value;
        const accentColor = document.getElementById('accent-color').value;
        const adType = adTypeSelect.value;

        // Get dimensions if custom size is selected
        let dimensions = null;
        if (adType === 'custom') {
            dimensions = {
                width: document.getElementById('width').value,
                height: document.getElementById('height').value
            };
        }

        if (!reference || !brandVoice || !targetAudience) {
            alert('Please fill in all required fields (Reference Content, Brand Voice, and Target Audience).');
            return;
        }

        // Show loading state
        loading.classList.remove('hidden');
        result.textContent = '';
        copyBtn.classList.add('hidden');
        generateBtn.disabled = true;

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    reference,
                    reference_image: referenceImage ? await fileToBase64(referenceImage) : null,
                    brand_voice: brandVoice,
                    target_audience: targetAudience,
                    brand_colors: {
                        primary: primaryColor,
                        secondary: secondaryColor,
                        accent: accentColor
                    },
                    ad_type: adType,
                    dimensions: dimensions
                })
            });

            const data = await response.json();

            if (data.success) {
                result.textContent = data.content;
                
                // Display the generated image
                const imageContainer = document.getElementById('image-container');
                const generatedImage = document.getElementById('generated-image');
                generatedImage.src = data.image_url;
                imageContainer.classList.remove('hidden');
                
                copyBtn.classList.remove('hidden');
            } else {
                result.textContent = `Error: ${data.error}`;
            }
        } catch (error) {
            result.textContent = `Error: ${error.message}`;
        } finally {
            loading.classList.add('hidden');
            generateBtn.disabled = false;
        }
    });

    copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(result.textContent)
            .then(() => {
                const originalText = copyBtn.textContent;
                copyBtn.textContent = 'Copied!';
                setTimeout(() => {
                    copyBtn.textContent = originalText;
                }, 2000);
            })
            .catch(err => {
                console.error('Failed to copy text:', err);
            });
    });
});
